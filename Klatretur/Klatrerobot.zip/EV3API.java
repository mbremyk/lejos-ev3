import lejos.hardware.Brick;
import lejos.hardware.BrickFinder;
import lejos.hardware.ev3.EV3;
import lejos.hardware.Keys;
import lejos.hardware.lcd.*;
import lejos.hardware.motor.*;
import lejos.hardware.port.SensorPort;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.*;
import lejos.hardware.Sound;

import lejos.hardware.*;

import lejos.robotics.SampleProvider;
import lejos.utility.Delay;

import java.lang.System.*;

public class EV3API {
	//Registrere hovedenhet
	private Brick brick = BrickFinder.getDefault();
	private EV3 ev3 = (EV3)BrickFinder.getLocal();

	//praktiske ting å ha
	private TextLCD lcd = ev3.getTextLCD();
	private Keys keys = ev3.getKeys();

	//registrering av sensorporter
	private Port s1 = brick.getPort("S1");
	private Port s2 = brick.getPort("S2");
	private Port s3 = brick.getPort("S3");
	private Port s4 = brick.getPort("S4");

	private NXTUltrasonicSensor topUS = new NXTUltrasonicSensor(s1);
	private EV3UltrasonicSensor leftUS = new EV3UltrasonicSensor(s2);
	private EV3UltrasonicSensor rightUS = new EV3UltrasonicSensor(s3);

	final SampleProvider topUSSP = topUS.getDistanceMode();
	final SampleProvider leftUSSP = leftUS.getDistanceMode();
	final SampleProvider rightUSSP = rightUS.getDistanceMode();

	final float[] topUSSample = new float[topUSSP.sampleSize()];
	final float[] leftUSSample = new float[leftUSSP.sampleSize()];
	final float[] rightUSSample = new float[rightUSSP.sampleSize()];

	public EV3API() {

	}

	//metode for å vente på keypress for å gå videre
	public void waitForKeyPress() throws Exception {
		keys.waitForAnyPress();
		Thread.sleep(200);
	}

	//metode for å lese antall knapper trykket inn
	public int readButtons() {
		return keys.readButtons();
	}

	public void turnLeft() {
		Motor.A.forward();
		//Motor.B.backward();
	}

	public void turnLeft(int speed) {
		Motor.A.setSpeed(speed);
		//Motor.B.setSpeed(speed);
		Motor.A.forward();
		//Motor.B.backward();
	}

	// public void turnLeft(int msec) throws Exception { //fikse
	// 	Motor.A.forward();
	// 	Motor.B.backward();
	// 	Thread.sleep(msec);
	// }

	public void turnRight() {
		//Motor.A.backward();
		Motor.B.forward();
	}

	public void turnRight(int speed) {
		//Motor.A.setSpeed(speed);
		Motor.B.setSpeed(speed);
		//Motor.A.backward();
		Motor.B.forward();
	}

	// public void turnRight(int msec) throws Exception { //fikse
	// 	Motor.A.backward();
	// 	Motor.B.forward();
	// 	Thread.sleep(msec);
	// }

	public void goForward() {
		Motor.A.forward();
		Motor.B.forward();
	}

	public void goForward(int speed) {
		Motor.A.setSpeed(speed);
		Motor.B.setSpeed(speed);
		Motor.A.forward();
		Motor.B.forward();
	}

	public void stop() {
		Motor.A.stop(true);
		Motor.B.stop(true);
		Motor.C.stop(true);
		Motor.D.stop(true);
	}

	public void lock() {
		Motor.A.lock(100);
		Motor.B.lock(100);
		Motor.C.lock(100);
		Motor.D.lock(100);
	}

	public void up() {
		Motor.D.forward();
	}

	public void up(int speed) {
		Motor.D.setSpeed(speed);
		Motor.D.forward();
	}

	// public void up(int msec) throws Exception {
	// 	Motor.D.forward();
	// 	Thread.sleep(msec);
	// }

	public void down() {
		Motor.D.backward();
	}

	public void down(int speed) {
		Motor.D.setSpeed(speed);
		Motor.D.backward();
	}

	// public void down(int msec) throws Exception {
	// 	Motor.D.backward();
	// 	Thread.sleep(msec);
	// }

	public void backForward() {
		Motor.C.forward();
	}

	public void backForward(int speed) {
		Motor.C.setSpeed(speed);
		Motor.C.forward();
	}

	public void backBack() {
		Motor.C.backward();
	}

	public void backBack(int speed) {
		Motor.C.setSpeed(speed);
		Motor.C.backward();
	}

	public void setSpeedAll(int speed)
	{
		Motor.A.setSpeed(speed);
		Motor.B.setSpeed(speed);
		Motor.C.setSpeed(speed);
		Motor.D.setSpeed(speed);
	}

	public void clear()
	{
		LCD.clear();
	}

	public void goUp(int speed) {
		long startMillis = System.currentTimeMillis();
		long millis = System.currentTimeMillis() - startMillis;

		if(speed > 900)
		{
			speed = 900;
		}

		while(readButtons() == 0) {
			millis = System.currentTimeMillis() - startMillis;

			topUSSP.fetchSample(topUSSample, 0);
			leftUSSP.fetchSample(leftUSSample, 0);
			rightUSSP.fetchSample(rightUSSample, 0);

			System.out.println(topUSSample[0] + "\n" + leftUSSample[0] + "\n" + rightUSSample[0] + "\n");
			System.out.println("Hoi!");

			// if(millis < 2000) {
			// 	goForward(speed / 5);
			// }
			// else if(millis < 22000) {
			// 	up(speed);
			// 	backForward(speed / 20);
			// }
			// else if(millis < 26000)
			// {
			// 	stop();
			// 	goForward();
			// }
			// else if(millis < 46000)
			// {
			// 	stop();
			// 	down(speed);
			// }
			// else if(millis < 50000)
			// {
			// 	stop();
			// 	goForward();
			// }
		}
	}

	public void write(String str, int x, int y) {
		if(x > 16) x = 16;
		if(y > 6) y = 6;
		LCD.drawString(str, x, y);
		//System.out.print(str);
	}

	// public void writeMid(String str) {
	// 	int l = str.length();
	// 	String[] strArr;

	// 	if(l > 17) {
	// 		strArr = new String[l / 17 + 1];
	// 		for(int i = 0; i < )
	// 	}
	// }

	public int speedMenu() {
		clear();
		int mySpeed = 200;
		write("Specify speed: " + mySpeed, 0, 0);
		int buttons = keys.waitForAnyPress(200);

		while (true) {
			switch (buttons) {
				case Keys.ID_DOWN:
					mySpeed -= 5;
					break;
				case Keys.ID_UP:
					mySpeed += 5;
					break;
				case Keys.ID_ENTER:
					Delay.msDelay(200);
					clear();
					return mySpeed;
				default:
					break;
			}
			clear();
			write("Specify speed: " + mySpeed, 0,0);
			buttons = keys.waitForAnyPress(200);
		}
	}
}