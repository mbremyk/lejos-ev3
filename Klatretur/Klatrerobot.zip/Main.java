public class Main
{
	public static void main(String[] args) {
		EV3API ev3 = new EV3API();

		int speed = ev3.speedMenu();
		ev3.goUp(speed);
		
		try{ev3.waitForKeyPress();}catch(Exception e){}
	}
}