import lejos.hardware.Brick;
import lejos.hardware.BrickFinder;
import lejos.hardware.ev3.EV3;
import lejos.hardware.Keys;
import lejos.hardware.lcd.*;
import lejos.hardware.motor.*;
import lejos.hardware.port.SensorPort;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.*;
import lejos.hardware.Sound;

import lejos.hardware.*;

import lejos.robotics.SampleProvider;
import lejos.utility.Delay;

import java.lang.System.*;

public class EV3API {
	//Registrere hovedenhet
	private Brick brick = BrickFinder.getDefault();
	private EV3 ev3 = (EV3)BrickFinder.getLocal();

	//praktiske ting å ha
	private TextLCD lcd = ev3.getTextLCD();
	private Keys keys = ev3.getKeys();

	//registrering av sensorporter
	private Port s1 = brick.getPort("S1");
	private Port s2 = brick.getPort("S2");
	private Port s3 = brick.getPort("S3");
	private Port s4 = brick.getPort("S4");

	private NXTUltrasonicSensor topUS;
	private EV3UltrasonicSensor leftUS;
	private EV3UltrasonicSensor rightUS;

	SampleProvider topUSSP;
	SampleProvider leftUSSP;
	SampleProvider rightUSSP;

	float[] topUSSample;
	float[] leftUSSample;
	float[] rightUSSample;

	float lastTopUSSample = 0f;
	float lastLeftUSSample = 0f;
	float lastRightUSSample = 0f;

	public Boolean near = false;
	public Boolean far = false;
	public Boolean climbable = false;
	public Boolean corner = false;
	public Boolean climbing = false;
	public Boolean sensorsWorking = true;

	final private float SENSOR_DIFF = 0.10f;
	final private float BOT_LENGTH = 0.20f;
	final private int MAX_TACHO_COUNT = 4160;
	final private int STAIR_KALVSKINNET_TACHO_COUNT = 3200;

	static SampleUpdater sampleUpdater;

	public EV3API() {
		Motor.A.resetTachoCount();
		Motor.B.resetTachoCount();
		Motor.C.resetTachoCount();
		Motor.D.resetTachoCount();

		try {
			topUS = new NXTUltrasonicSensor(s1);
			leftUS = new EV3UltrasonicSensor(s2);
			rightUS = new EV3UltrasonicSensor(s3);

			topUSSP = topUS.getDistanceMode();
			leftUSSP = leftUS.getDistanceMode();
			rightUSSP = rightUS.getDistanceMode();

			topUSSample = new float[topUSSP.sampleSize()];
			leftUSSample = new float[leftUSSP.sampleSize()];
			rightUSSample = new float[rightUSSP.sampleSize()];
		} catch (Exception e) {
			write(e.toString());
			sensorsWorking = false;
		}

		sampleUpdater = new SampleUpdater();
	}

	//metode for å vente på keypress for å gå videre
	public void waitForKeyPress() throws Exception {
		keys.waitForAnyPress();
		Thread.sleep(200);
	}

	//metode for å lese antall knapper trykket inn
	public int readButtons() {
		return keys.readButtons();
	}

	public void turnLeft() {
		Motor.A.forward();
		//Motor.B.backward();
	}

	public void turnLeft(int speed) {
		Motor.A.setSpeed(speed);
		//Motor.B.setSpeed(speed);
		Motor.A.forward();
		//Motor.B.backward();
	}

	public void turnRight() {
		//Motor.A.backward();
		Motor.B.forward();
	}

	public void turnRight(int speed) {
		//Motor.A.setSpeed(speed);
		Motor.B.setSpeed(speed);
		//Motor.A.backward();
		Motor.B.forward();
	}

	public void goForward() {
		Motor.A.forward();
		Motor.B.forward();
		Motor.C.forward();
	}

	public void goForward(int speed) {
		Motor.A.setSpeed(speed);
		Motor.B.setSpeed(speed);
		Motor.C.setSpeed(speed);
		Motor.A.forward();
		Motor.B.forward();
		Motor.C.forward();
	}

	public void goClimbForward(int speed) {
		Motor.A.setSpeed(speed);
		Motor.B.setSpeed(speed);
		Motor.C.setSpeed(speed / 8);
		Motor.A.forward();
		Motor.B.forward();
		Motor.C.forward();
	}

	public void stop() {
		Motor.A.stop(true);
		Motor.B.stop(true);
		Motor.C.stop(true);
		Motor.D.stop(true);
	}

	public void lock() {
		Motor.A.lock(100);
		Motor.B.lock(100);
		Motor.C.lock(100);
		Motor.D.lock(100);
	}

	public void goUp() {
		Motor.D.forward();
	}

	public void goUp(int speed) {
		Motor.D.setSpeed(speed);
		Motor.D.forward();
	}

	public void goDown() {
		Motor.D.backward();
	}

	public void goDown(int speed) {
		Motor.D.setSpeed(speed);
		Motor.D.backward();
	}

	public void backForward() {
		Motor.C.forward();
	}

	public void backForward(int speed) {
		Motor.C.setSpeed(speed);
		Motor.C.forward();
	}

	public void backBackward() {
		Motor.C.backward();
	}

	public void backBackward(int speed) {
		Motor.C.setSpeed(speed);
		Motor.C.backward();
	}

	public void setSpeedAll(int speed) {
		Motor.A.setSpeed(speed);
		Motor.B.setSpeed(speed);
		Motor.C.setSpeed(speed);
		Motor.D.setSpeed(speed);
	}

	public void clear() {
		LCD.clear();
	}

	public void rotateDTo0() {
		Motor.D.rotateTo(0);
	}

	public void goIn(int speed) {
		Motor.A.setSpeed(speed / 3);
		Motor.B.setSpeed(speed / 3);
		Motor.C.setSpeed(speed);
		Motor.A.forward();
		Motor.B.forward();
		Motor.C.forward();
	}

	public void climbUpStep(int speed, Boolean kalvskinnet) {
		long startMillis = System.currentTimeMillis();
		long millis = System.currentTimeMillis() - startMillis;

		if (speed < 0) {
			speed = 0;
		}

		if (speed > 900) {
			speed = 900;
		}

		if (kalvskinnet) {
			climbing = true;
			while(readButtons() == 0 && climbing) {
				millis = System.currentTimeMillis() - startMillis;
				kalvskinnetClimb(speed, millis);
			}
		} else if (readButtons() == 0 && climbing) {
			while (readButtons() == 0) {
				millis = System.currentTimeMillis() - startMillis;

				if (Motor.D.getTachoCount() >= MAX_TACHO_COUNT) {
					Motor.D.rotateTo(MAX_TACHO_COUNT);
					Motor.D.stop();
				} else if (!(leftUSSample[0] == Float.POSITIVE_INFINITY && rightUSSample[0] == Float.POSITIVE_INFINITY)) {
					goForward();
					backForward();
				} else if (Motor.D.getTachoCount() < MAX_TACHO_COUNT) {
					goUp();
				}
			}
		}
		sampleUpdaterStop();
	}


	public void write(String str, int x, int y) {
		if(x > 16) x = 16;
		if(y > 6) y = 6;
		LCD.drawString(str, x, y);
		//System.out.print(str);
	}

	public void write(String str)
	{
		System.out.println(str);
	}

	// public void writeMid(String str) {
	// 	int l = str.length();
	// 	String[] strArr;

	// 	if(l > 17) {
	// 		strArr = new String[l / 17 + 1];
	// 		for(int i = 0; i < )
	// 	}
	// }

	public int speedMenu() {
		clear();
		int mySpeed = 200;
		write("Specify speed: " + mySpeed, 0, 0);
		int buttons = keys.waitForAnyPress(200);

		while (true) {
			switch (buttons) {
				case Keys.ID_DOWN:
				mySpeed -= 5;
				break;
				case Keys.ID_UP:
				mySpeed += 5;
				break;
				case Keys.ID_ENTER:
				Delay.msDelay(200);
				clear();
				return mySpeed;
				default:
				break;
			}
			clear();
			write("Specify speed: " + mySpeed, 0,0);
			buttons = keys.waitForAnyPress(200);
		}
	}

	static void sampleUpdaterStart() {
		sampleUpdater.start();
	}

	static void sampleUpdaterStop() {
		sampleUpdater.interrupt();
	}

	//Sample updating method
	void updateSamples() {
		SampleUpdater.threadMark = "updateSamples(): enter updateSamples()";

		if(!(topUSSample[0] == Float.POSITIVE_INFINITY)) {
			lastTopUSSample = topUSSample[0];
		}

		if(!(leftUSSample[0] == Float.POSITIVE_INFINITY)) {
			lastLeftUSSample = leftUSSample[0];
		}

		if(!(rightUSSample[0] == Float.POSITIVE_INFINITY)) {
			lastRightUSSample = rightUSSample[0];
		}

		SampleUpdater.threadMark = "updateSamples(): fetch samples";
		topUSSP.fetchSample(topUSSample, 0);
		leftUSSP.fetchSample(leftUSSample, 0);
		rightUSSP.fetchSample(rightUSSample, 0);

		SampleUpdater.threadMark = "updateSamples(): sample correction";
		if ((lastLeftUSSample < 0.10f && lastRightUSSample < 0.10f) && (leftUSSample[0] == Float.POSITIVE_INFINITY || rightUSSample[0] == Float.POSITIVE_INFINITY)) {
			near = true;
			far = false;
			corner = false;
		} else if ((lastLeftUSSample > 0.50f && lastRightUSSample > 0.50f) && (leftUSSample[0] == Float.POSITIVE_INFINITY || rightUSSample[0] == Float.POSITIVE_INFINITY)) {
			near = false;
			far = true;
			corner = false;
		} else if (((lastLeftUSSample > 0.50f && lastRightUSSample < 0.10f) || (lastLeftUSSample < 0.10f && lastRightUSSample > 0.50f)) && (leftUSSample[0] == Float.POSITIVE_INFINITY && rightUSSample[0] == Float.POSITIVE_INFINITY)) {
			near = false;
			far = false;
			corner = true;
		} else {
			near = false;
			far = false;
			corner = false;
		}

		SampleUpdater.threadMark = "updateSamples(): set climbable";
		if (topUSSample[0] > BOT_LENGTH + SENSOR_DIFF || topUSSample[0] == Float.POSITIVE_INFINITY) {
			climbable = true;
		} else {
			climbable = false;
		}
	}

	private void kalvskinnetClimb(int speed, long millis) {

		if (millis < 3000) {	//løfte front
			goForward(speed / 5);
		} else if (millis < 11500) { 	//klatre opp
			goClimbForward(speed / 5);
			goUp(speed);
		} else if (millis < 11600) {
			stop();
		} else if (millis < 12500) {		//kjøre inn
			goIn(speed / 5);
		} else if (millis < 12600) { //vente litt
			stop();
		} else if (millis < 23500) {	   //løfte bak
			rotateDTo0();
		} else if (millis < 23600) {
			stop();
		} else if (millis < 28500) {		//kjøre mer inn
			goForward(speed / 5);
		} else {
			stop();
			climbing = false;
		}
	}
}