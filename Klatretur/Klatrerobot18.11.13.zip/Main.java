public class Main
{
	public static EV3API ev3;
	public static void main(String[] args) {
		ev3 = new EV3API();

		int speed = ev3.speedMenu();
		EV3API.sampleUpdaterStart();
		while (ev3.readButtons() == 0) {
			ev3.write(ev3.topUSSample[0] + "\n" + ev3.leftUSSample[0] + "\n" + ev3.rightUSSample[0]);
		}
		EV3API.sampleUpdaterStop();
		//ev3.write(ev3.topUSSample[0] + "\n" + ev3.leftUSSample[0] + "\n" + ev3.rightUSSample[0]);
		//ev3.climbUpStep(speed, true);
	}
}