import java.lang.System.*;

public class Main
{
	public static EV3API ev3 = new EV3API();
	public static void main(String[] args) {

		int speed = ev3.speedMenu();
		long startMillis = System.currentTimeMillis();
		long millis = System.currentTimeMillis() - startMillis;
		ev3.setSpeed(speed);
		EV3API.sampleUpdaterStart();
		while (ev3.readButtons() == 0) {
			millis = System.currentTimeMillis() - startMillis;
			//ev3.write(ev3.topUSSample[0] + "\n" + ev3.leftUSSample[0] + "\n" + ev3.rightUSSample[0]);
			ev3.lcd.clear();
			ev3.write(Boolean.toString(ev3.climbing));
			if (!ev3.climbing) {
				ev3.searchForStep(millis);
			}
			//ev3.climbUpStep(true);
		}
		EV3API.sampleUpdaterStop();
		//ev3.write(ev3.topUSSample[0] + "\n" + ev3.leftUSSample[0] + "\n" + ev3.rightUSSample[0]);
		//ev3.climbUpStep(speed, true);
	}
}