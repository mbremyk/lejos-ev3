//Create only one instance of this thread!
class SampleUpdater extends Thread {

	public static String threadMark = "SampleUpdater: thread init";

	void err(String s) {
		System.err.print(s);
	}

	void errln(String s) {
		System.err.println(s);
	}

	void out(String s) {
		System.out.print(s);
	}

	void outln(String s) {
		System.out.println(s);
	}

	//thread-local sleep function
	void sleep(int ms) {
		threadMark = "sleep(): enter sleep";
		try {
			Thread.sleep(30 - ms);
		} catch (Exception ThreadSleepException) {
			err("\nError @ " + threadMark + "\n");
			outln("Error: SampleUpdater.run(@while -> thread.sleep)");
		}
	}

	public void run() {
		try {
			threadMark = "run(): start run()";
			long millisStart;
			long millisEnd;
			long threadTimer;
			while (!interrupted()) {
				threadMark = "run(): start while(!isInterrputed)";
				millisStart = System.currentTimeMillis();

				Main.ev3.updateSamples();

				threadMark = "run(): exit updateSamples()";
				millisEnd = System.currentTimeMillis();
				threadTimer = millisEnd - millisStart;
				if (threadTimer < 0) threadTimer = 0;
				if (threadTimer > 30) threadTimer = 30;

				threadMark = "run(): start sleep";
				sleep(threadTimer);

				threadMark = "run(): while end";
			}

			threadMark = "run(): end thread: was interrupted";
			errln(threadMark);
			outln(threadMark);

		} catch (Exception e) {
			err("\nError in thread Sample Updater \nThreadmark was " + threadMark + "\n");
			errln(e.toString());
			outln(e.toString());
		}
	}
}